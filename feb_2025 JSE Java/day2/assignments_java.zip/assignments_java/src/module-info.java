/**
 * 
 */
/**
 * 
 */
module assignments_java {
}