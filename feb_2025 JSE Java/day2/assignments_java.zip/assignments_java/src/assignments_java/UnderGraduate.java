package assignments_java;

public class UnderGraduate extends Degree {

	@Override
	public void getDegree() {
		System.out.println(" i am UnderGraduate ");
	}
}
