package assignments_java;

public class RegualrOrder extends Order {

	public RegualrOrder(int orderid, float totalCost) {
		super(orderid, totalCost);
	}

	public void calculatedDeliveryTime() {
		super.calculatedDeliveryTime();
	}

	public void displayDetails() {
		super.displayDetails();
		
	}

}
