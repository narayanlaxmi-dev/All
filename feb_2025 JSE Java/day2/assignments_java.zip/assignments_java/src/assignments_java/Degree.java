package assignments_java;

public class Degree {
	public void getDegree() {
		System.out.println(" i Got Degree");
	}
}
