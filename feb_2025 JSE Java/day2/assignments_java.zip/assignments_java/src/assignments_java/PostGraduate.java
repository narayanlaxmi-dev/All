package assignments_java;

public class PostGraduate extends Degree {

	@Override
	public  void getDegree() {
		System.out.println(" i am PostGraduate ");
	}
}
