package assignments_java;

public class Bank {
	protected static double Intrest = 0;

	public double getBalance() {
		return 0;
	}

	public double applyBalance() {
		return getBalance();
	}
}
