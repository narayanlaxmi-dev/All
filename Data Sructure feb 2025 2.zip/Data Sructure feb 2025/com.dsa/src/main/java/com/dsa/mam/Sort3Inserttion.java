package com.dsa.mam;

import java.util.Scanner;

class searchInsertion {
	void binaryInsertion(int[] arr, int size) {
		int newEle, i, j;
		for (i = 0; i < size-1; i++) {

			newEle = arr[i + 1]; // second value store in new var
			j = i + 1;// second index store in new var

			while (j > 0 && arr[j - 1] > newEle) {
				arr[j] = arr[j - 1];
				j--;
			}
			// swap i index to min and so on
			arr[j] = newEle;
		}
	}

	void print(int arr[]) {
		System.out.print("Sorted Array: ");
		for (int i = 0; i < arr.length; i++)
			System.out.print(arr[i] + " | ");
	}

}

public class Sort3Inserttion {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size:");
		int size = sc.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter element: size:"+size);
		for (int i = 0; i < size; i++) {
			arr[i] = sc.nextInt();
		}
		
		searchSelection o = new searchSelection();
		o.binarySelection(arr, size);
		o.print(arr);
		sc.close();
	}
}
