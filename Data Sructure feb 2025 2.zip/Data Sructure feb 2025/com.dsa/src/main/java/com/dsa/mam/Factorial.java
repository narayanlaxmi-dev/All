package com.dsa.mam;

import java.util.Scanner;

public class Factorial {
	public static void main(String[] args) {
		int num = 0;
		System.out.println("---Factorial Program---\n negative number:-0\n\n Enter number: ");
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();
		System.out.println("The number sent" + num + " factorial is : " + factorialfun1(num));
		sc.close();
	}

	public static int factorialfun(int x) {
		if (x >= 1)
			return x * factorialfun(x - 1);
		else if (x == 0)
			return 1;
		else
			return 0;
	}
	
	public static int factorialfun1(int x) {
		int result =1;
		for (int i=2; i<=x; i++)
			result *=i;
		return result;
	}
}
