package com.dsa.mam;

import java.util.Scanner;

public class ArrayLinerSearch {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("---Array linear search Program---\n Enter number ofr array size: ");
		int size = sc.nextInt();
		int arr[] = new int[size];

		System.out.println("Enter elements for size: " + size);
		for (int i = 0; i < size; i++)
			arr[i] = sc.nextInt();

		System.out.println("Enter Key:");
		int key = sc.nextInt();
		for (int i = 0; i < size; i++)
			System.out.print(arr[i]+ ",");

		System.out.println("\n\nThe value " + key + " index is found at: " + sequentialSearch(arr, size, key));
		sc.close();
	}

	public static int sequentialSearch(int a[], int s, int k) {
		for (int i = 0; i < s; i++) {
			if (a[i] == k) {				
				System.out.println("\nvalue is"+a[i]);
				return i;
				
			}
		}
		return -1;
	}
}
