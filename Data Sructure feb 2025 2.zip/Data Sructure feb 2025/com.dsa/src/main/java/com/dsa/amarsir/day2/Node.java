package com.dsa.amarsir.day2;

public class Node {
	int data;
	Node next;

	public Node(int data) {
		this.data = data;
		next = null;
	}

}
