package com.dsa.mam;

import java.util.Arrays;
import java.util.Scanner;

class search {
	int binarySearch(int arr[], int start, int end, int key) {

		if (start <= end) {
			int mid = (start + end) / 2;
			if (key == arr[mid])
				return mid;

			else {
//				if (key < arr[mid])
//					return binarySearch(arr, start, mid - 1, key);
//				else
//					return binarySearch(arr, mid + 1, end, key);
				return (key < arr[mid]) ? binarySearch(arr, start, mid - 1, key) : binarySearch(arr, mid + 1, end, key);
			}

		} else
			return -1;
	}
}

public class BinarySearch {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("---Array linear search Program---\n Enter number ofr array size: "); // element always
																									// sorted
		int size = sc.nextInt();
		int arr[] = new int[size];

		System.out.println("Enter elements for size: " + size);
		for (int i = 0; i < size; i++)
			arr[i] = sc.nextInt();

		System.out.println("Enter Key:");
		int key = sc.nextInt();

//		-----------------------------------------------------------------------------------------------------------
		search obj = new search();
		Arrays.sort(arr); // sorted array if array not sorted
		for (int i = 0; i < size; i++)
			System.out.print(arr[i] + ",");

		System.out.println("\nThe value is found at index :" + obj.binarySearch(arr, 0, size - 1, key));
		System.out.println("|-----------|\n" + binarySearchOptimal(arr, 0, size, key));
		sc.close();
	}

	public static int binarySearchOptimal(int arr[], int start, int end, int key) {
		while (start <= end) {
			int mid = start + (end - start) / 2; // prevent overflow
			if (arr[mid] == key)
				return mid;
			else if (key < arr[mid])
				end = mid - 1;
			else
				start = mid + 1;
		}
		return -1;
	}
}
