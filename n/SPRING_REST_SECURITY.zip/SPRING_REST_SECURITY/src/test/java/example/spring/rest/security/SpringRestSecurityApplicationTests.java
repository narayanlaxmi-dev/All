package example.spring.rest.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
