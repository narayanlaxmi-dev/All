package assignment8.bank;

public interface BankService {

	void loanService();

}
