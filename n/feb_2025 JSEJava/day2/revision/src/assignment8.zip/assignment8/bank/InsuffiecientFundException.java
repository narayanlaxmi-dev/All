package assignment8.bank;

public class InsuffiecientFundException extends Exception{

	 public InsuffiecientFundException(String msg) {
		super(msg);
	}
}