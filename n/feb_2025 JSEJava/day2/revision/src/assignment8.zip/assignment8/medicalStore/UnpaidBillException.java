package assignment8.medicalStore;

public class UnpaidBillException extends Exception {
	public UnpaidBillException(String msg) {
		super(msg);
	}
}
