package assignment8.medicalStore;

public interface MedicalServices {
	public void Treatment();
}
