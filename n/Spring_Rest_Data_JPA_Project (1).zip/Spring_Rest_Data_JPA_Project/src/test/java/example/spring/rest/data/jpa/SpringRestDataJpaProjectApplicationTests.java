package example.spring.rest.data.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestDataJpaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
